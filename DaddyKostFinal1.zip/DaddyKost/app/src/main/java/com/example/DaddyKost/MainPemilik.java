package com.example.DaddyKost;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.DaddyKost.databinding.ActivityMainPemilikBinding;

import java.util.ArrayList;
import java.util.List;

public class MainPemilik extends AppCompatActivity implements KostAdapter.KostAdapterCallback {
    private Button TmbhKost;
    private ActivityMainPemilikBinding binding;
    private KostAdapter kostAdapter;
    private ViewTabelPengguna kostViewModel;
    AlertDialog.Builder builder;

    private List<Kost> mKosts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainPemilikBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initAdapter();
        observeData();
    }

    private void initAdapter() {
        kostAdapter = new KostAdapter(this, mKosts, this);
        binding.rvKosts.setLayoutManager(new LinearLayoutManager(this));
        binding.rvKosts.setItemAnimator(new DefaultItemAnimator());
        binding.rvKosts.setAdapter(kostAdapter);
        binding.btnTambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent ini = new Intent(MainPemilik.this,TambahKost.class);
                startActivity(ini);
            }
        });
    }

    private void observeData() {
        kostViewModel = ViewModelProviders.of(this).get(ViewTabelPengguna.class);
        kostViewModel.getKosts().observe(this,
                new Observer<List<Kost>>() {
                    @Override
                    public void onChanged(List<Kost> Kosts) {
                        kostAdapter.addData(Kosts);
                    }
                });
    }


    @Override
    public void onDelete(Kost kost) {
        int uid = kost.idKost;
        builder = new AlertDialog.Builder(this);
        //Uncomment the below code to Set the message and title from the strings.xml file
        builder.setMessage(R.string.dialog_message).setTitle(R.string.dialog_title);

        //Setting message manually and performing action on button click
        builder.setMessage("Apakah anda yakin akan menghapus data Kost dengan id = "+uid+"?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        //fungsi delete
                        kostViewModel.deleteSingleData(uid);

                        Toast.makeText(getApplicationContext(),"Anda berhasil menghapus data Kost",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Action for 'NO' Button
                        dialog.cancel();
                        Toast.makeText(getApplicationContext(),"Anda tidak jadi menghapus data kost",
                                Toast.LENGTH_SHORT).show();
                    }
                });
        //Creating dialog box
        AlertDialog alert = builder.create();
        //Setting the title manually
        alert.setTitle("Hapus data Kost");
        alert.show();
    }
    public void lokasiKost(Kost kost){
        int uid = kost.idKost;
        String url = kost.gmap;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

    @Override
    public void onEdit(Kost kost) {
        Integer uid = kost.idKost;
        Intent i = new Intent(MainPemilik.this, ubahdataKost.class).putExtra("ubah", uid);
        startActivity(i);
    }

}