package com.example.DaddyKost;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Kost")
public class Kost implements Parcelable {
    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "idKost")
    public Integer idKost;

    @ColumnInfo(name = "fasilitasKost")
    public String fasilitasKost;

    @ColumnInfo(name = "namaKost")
    public String namaKost;

    @ColumnInfo(name = "alamatKost")
    public String alamatKost;

    @ColumnInfo(name = "kontakKost")
    public String kontakKost;

    @ColumnInfo(name = "gmap")
    public String gmap;

    public Kost() {

    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.idKost);
        dest.writeString(this.fasilitasKost);
        dest.writeString(this.namaKost);
        dest.writeString(this.kontakKost);
        dest.writeString(this.alamatKost);
        dest.writeString(this.gmap);
    }
    protected Kost(Parcel in) {
        this.idKost = in.readInt();
        this.fasilitasKost =in.readString();
        this.namaKost = in.readString();
        this.kontakKost = in.readString();
        this.alamatKost = in.readString();
        this.gmap = in.readString();
    }

    public static final Parcelable.Creator<Kost> CREATOR = new Parcelable.Creator<Kost>() {
        @Override
        public Kost createFromParcel(Parcel source) {
            return new Kost(source);
        }

        @Override
        public Kost[] newArray(int size) {
            return new Kost[size];
        }
    };
}
