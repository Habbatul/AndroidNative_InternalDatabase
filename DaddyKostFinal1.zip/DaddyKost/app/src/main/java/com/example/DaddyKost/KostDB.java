package com.example.DaddyKost;

import android.content.Context;

import androidx.room.Room;

public class KostDB {
    private static KostEntity instance;

    public static KostEntity getInstance(Context context) {
        if(KostDB.instance == null)
        {
            KostDB.instance = Room.databaseBuilder(context, KostEntity.class, "Kost_DB.db").allowMainThreadQueries().build();
        }
        return KostDB.instance;
    }

}
