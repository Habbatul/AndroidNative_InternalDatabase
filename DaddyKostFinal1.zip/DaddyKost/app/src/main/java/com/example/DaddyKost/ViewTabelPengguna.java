package com.example.DaddyKost;

import android.app.Application;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import java.util.List;

import io.reactivex.Completable;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.functions.Action;
import io.reactivex.schedulers.Schedulers;

public class ViewTabelPengguna extends AndroidViewModel {
    Context context;
    private LiveData<List<Kost>> mKosts;
    private KostDao kostDao;

    public ViewTabelPengguna(@NonNull Application application) {
        super(application);

        kostDao = KostDB.getInstance(application).kostDao();
        mKosts = (LiveData<List<Kost>>) kostDao.getAll();
    }
    public LiveData<List<Kost>> getKosts() {
        return mKosts;
    }

    public void deleteSingleData(int uid) {
        Completable.fromAction(new Action() {
                    @Override
                    public void run() throws Exception {
                        kostDao.deleteSingleData(uid);
                    }
                })
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe();
    }


}