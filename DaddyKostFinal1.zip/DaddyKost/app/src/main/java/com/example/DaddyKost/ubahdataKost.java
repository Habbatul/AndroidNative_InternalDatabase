package com.example.DaddyKost;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ubahdataKost extends AppCompatActivity {
    private EditText edtFasilitas;
    private EditText edtNama;
    private EditText edtAlamat;
    private EditText edtKontak;
    private EditText edtGmap;
    private Button btnUbah;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubahdata_kost);
        this.btnUbah = this.findViewById(R.id.btn_ubahKost);
        this.edtNama = this.findViewById(R.id.namaKost);
        this.edtGmap = this.findViewById(R.id.GMAP);
        this.edtAlamat = this.findViewById(R.id.alamatKost);
        this.edtKontak = this.findViewById(R.id.kontakKost);
        this.edtFasilitas = this.findViewById(R.id.fasilitasKost);
        KostDao kost;
        kost = KostDB.getInstance(getBaseContext()).kostDao();
        Bundle extras = getIntent().getExtras();
        int uid = extras.getInt("ubah");


        Kost daftarKost = kost.ambilSingleData(uid);
        edtNama.setText(daftarKost.namaKost);
        edtGmap.setText(daftarKost.gmap);
        edtAlamat.setText(daftarKost.alamatKost);
        edtKontak.setText(daftarKost.kontakKost);
        edtFasilitas.setText(daftarKost.fasilitasKost);

        this.btnUbah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean valid = validasi();
                if (valid) {
                    KostDao kost = KostDB.getInstance(getApplicationContext()).kostDao();
                    kost.ubahSingleData(edtFasilitas.getText().toString(),
                            edtNama.getText().toString(),edtAlamat.getText().toString(),
                            edtKontak.getText().toString(),edtGmap.getText().toString(),uid);
                    Toast.makeText(ubahdataKost.this, "Ubah data kost berhasil", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
    }

    private Kost buatKost() {
        Kost u = new Kost();
        u.namaKost = this.edtNama.getText().toString().trim();
        u.gmap = this.edtGmap.getText().toString().trim();
        u.alamatKost = this.edtAlamat.getText().toString().trim();
        u.kontakKost = this.edtKontak.getText().toString().trim();
        u.fasilitasKost = this.edtFasilitas.getText().toString().trim();
        return u;
    }

    private boolean validasi() {
        String namaKost = this.edtNama.getText().toString().trim();
        String gmap = this.edtGmap.getText().toString().trim();
        String alamatKost = this.edtAlamat.getText().toString().trim();
        String kontakKost = this.edtKontak.getText().toString().trim();
        String fasilitasKost = this.edtFasilitas.getText().toString().trim();

        if (namaKost.isEmpty())
            Toast.makeText(this, "Nama masih kosong!", Toast.LENGTH_SHORT).show();
        else if (gmap.isEmpty())
            Toast.makeText(this, "Url google map masih kosong!", Toast.LENGTH_SHORT).show();
        else if (alamatKost.isEmpty())
            Toast.makeText(this, "alamat masih kosong!", Toast.LENGTH_SHORT).show();
        else if (kontakKost.isEmpty())
            Toast.makeText(this, "kontak masih kosong!", Toast.LENGTH_SHORT).show();
        else if (fasilitasKost.isEmpty())
            Toast.makeText(this, "fasilitas masih kosong!", Toast.LENGTH_SHORT).show();
        else {
            KostDao user = KostDB.getInstance(getApplicationContext()).kostDao();
            Pengguna currentUserData = user.findByNama(gmap);
            if (currentUserData != null)
                Toast.makeText(this, "Kost yang ingin didaftarkan sudah ada!", Toast.LENGTH_SHORT).show();
            else
                return true;
        }
        return false;
    }
}