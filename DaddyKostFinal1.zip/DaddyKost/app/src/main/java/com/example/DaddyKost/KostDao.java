package com.example.DaddyKost;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface KostDao {
    @Query("SELECT * FROM Kost")
    LiveData<List<Kost>> getAll();

    @Query("SELECT * FROM Kost WHERE idKost IN (:ID)")
    List<Kost> loadAllByIds(int[] ID);

    @Query("SELECT gmap FROM Kost WHERE idKost= :uid")
    String getGmap(int uid);

    @Insert
    void insertAll1(Kost... kosts);

    @Query("DELETE FROM Kost WHERE idKost= :uid")
    void deleteSingleData(int uid);

    @Query("SELECT * FROM Kost WHERE idKost= :uid LIMIT 1")
    Kost ambilSingleData(int uid);

    @Query("UPDATE Kost SET fasilitasKost= :fslts, namaKost= :nm, alamatKost= :almt, KontakKost= :kntk, gmap= :gmp WHERE idKost= :uid")
    void ubahSingleData(String fslts, String nm, String almt, String kntk, String gmp, int uid);

    @Delete
    void delete(Kost kost);
    @Query("SELECT * FROM Pengguna")
    List<Pengguna> getAll1();

    @Query("SELECT * FROM Pengguna WHERE id IN (:userID)")
    List<Pengguna> loadAllByIds1(int[] userID);

    @Query("SELECT * FROM Pengguna WHERE id= :userID AND password = :password LIMIT 1")
    Pengguna findByIDAndPassword(Integer userID, String password);

    //nanti diubah
    @Query("SELECT nama FROM Pengguna WHERE id= :userID LIMIT 1")
    String namaPengguna(String userID);

    @Query("SELECT id FROM Pengguna WHERE nama = :nama LIMIT 1")
    Integer findByID(String nama);

    @Query("SELECT tipe FROM Pengguna WHERE nama = :nama LIMIT 1")
    String findTipe(String nama);

    @Query("SELECT * FROM Pengguna WHERE nama = :nama LIMIT 1")
    Pengguna findByNama(String nama);

    @Insert
    void insertAll(Pengguna... users);

    @Delete
    void delete(Pengguna user);
}
