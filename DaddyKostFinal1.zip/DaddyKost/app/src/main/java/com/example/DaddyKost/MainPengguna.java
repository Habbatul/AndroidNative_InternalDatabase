package com.example.DaddyKost;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.example.DaddyKost.databinding.ActivityMainPenggunaBinding;

import java.util.ArrayList;
import java.util.List;

public class MainPengguna extends AppCompatActivity implements KostAdapterDua.KostAdapterDuaCallback {
    private ActivityMainPenggunaBinding binding;
    private KostAdapterDua kostAdapterDua;
    private ViewTabelPengguna kostViewModel;

    private List<Kost> mKosts = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainPenggunaBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initAdapter();
        observeData();
    }

    private void initAdapter() {
        kostAdapterDua = new KostAdapterDua(this, mKosts, this);
        binding.rvPengguna.setLayoutManager(new LinearLayoutManager(this));
        binding.rvPengguna.setItemAnimator(new DefaultItemAnimator());
        binding.rvPengguna.setAdapter(kostAdapterDua);
    }

    private void observeData() {
        kostViewModel = ViewModelProviders.of(this).get(ViewTabelPengguna.class);
        kostViewModel.getKosts().observe(this,
                new Observer<List<Kost>>() {
                    @Override
                    public void onChanged(List<Kost> Kosts) {
                        kostAdapterDua.addData(Kosts);
                    }
                });



    }

    public void lokasiKost(Kost kost){
        int uid = kost.idKost;
        String url = kost.gmap;
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(url));
        startActivity(intent);
    }

}