package com.example.DaddyKost;

import androidx.room.Database;
import androidx.room.RoomDatabase;

    @Database(entities = {Kost.class, Pengguna.class}, version = 1, exportSchema = false)
    public abstract class KostEntity extends RoomDatabase {
        public abstract KostDao kostDao();
    }
