package com.example.DaddyKost;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.DaddyKost.databinding.ItemPenggunaBinding;

import java.util.List;

public class KostAdapterDua extends RecyclerView.Adapter<KostAdapterDua.ViewHolder> {

    private static final String TAG = KostAdapterDua.class.getSimpleName();

    private Context context;
    private List<Kost> list;
    private KostAdapterDua.KostAdapterDuaCallback mAdapterCallback;
    private ItemPenggunaBinding binding;

    public KostAdapterDua(Context context, List<Kost> list, KostAdapterDua.KostAdapterDuaCallback adapterCallback) {
        this.context = context;
        this.list = list;
        this.mAdapterCallback = (KostAdapterDuaCallback) adapterCallback;
    }

    @Override
    public KostAdapterDua.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        binding = ItemPenggunaBinding.inflate(LayoutInflater
                .from(parent.getContext()), parent, false);
        return new KostAdapterDua.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(KostAdapterDua.ViewHolder holder, int position) {
        Kost item = list.get(position);
        holder.bindData(item);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public void addData(List<Kost> Kosts){
        this.list = Kosts;
        notifyDataSetChanged();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        ViewHolder(@NonNull ItemPenggunaBinding itemView) {
            super(itemView.getRoot());
            binding.tvAlamatKost.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Kost kost = list.get(getAdapterPosition());
                    mAdapterCallback.lokasiKost(kost);
                }
            });
        }
        void bindData(Kost item) {
            Integer uid = item.idKost;
            String gmap_url = item.gmap;

            String note1 = item.namaKost;
            binding.tvNamakost.setText(note1);

            String note2 = item.alamatKost;
            binding.tvAlamatKost.setText(note2);

            String note3 = item.fasilitasKost;
            binding.tvFasilitas.setText(note3);

            String note4 = item.kontakKost;
            binding.tvKontakKost.setText(note4);

            binding.judulAlamat.setText("Alamat : ");
            binding.judulFasilitas.setText("Fasilitas :");
        }

    }

    public interface KostAdapterDuaCallback {
        void lokasiKost(Kost kost);
    }

}
